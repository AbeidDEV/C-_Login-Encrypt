# C#_Login_Encrypt
Login Encrypt SHA-256 / Secure with C# and MySQL
Login Encrypt SHA-254 / Secure with C# and MySQL
Login 12-41 Hash codes / Secure with C# and MySQL
